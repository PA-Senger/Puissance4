"""
    fct_puissance4 contient les fonctions servant a la programmation d'un jeu 
    simple de puissance4
"""


def create_new_game():
    """create a new matrice filled with None
    return : list, matrice
    """
    set = []
    for i in range(6):
        set += [[]]
        for j in range(7):
            set[i] += [None]
    return set


def check_col(y, l):
    """check if the column is playable
    param y : int, coord of the col
    param l : lst, matrice du jeu
    return : bool, True if playble else False
    """
    for i in range(len(l)):
        if l[i][y] == None:
            return True
    return False


def clic_col(a):
    """return the column corresponding when the player clic
    param a : couple, coord in the matrice
    return : int, col
    """
    return a[1]


def drop_coord(y, l):
    """find the coord for the token to land
    param y : int, column
    param l : list, matrice of the game
    return : couple, coord for the token of the player
    """
    for i in range(len(l)):
        if l[i][y] != None:
            return (i-1, y)
    return (i, y)


# condition de victoire
#diagonale1
def diag1(cell, joueur, l):
    """loop search in diag for player's token
    param cell: couple, coord token
    param joueur: int, player
    param l: list, matrice
    """
    win = 1
    x, y = cell
    checkpoint = [cell]
    while l[x][y] == joueur :
        x -= 1
        y -= 1
        if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur :
            win += 1
        else :
            cell = checkpoint[0]
            x, y = cell
            while l[x][y] == joueur :
                x += 1
                y += 1
                if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur:
                    win +=1
                else :
                    return win
    return win


#diagonale2
def diag2(cell, joueur, l):
    """loop search in diag for player's token
    param cell: couple, coord token
    param joueur: int, player
    param l: list, matrice
    """
    win = 1
    x, y = cell
    checkpoint = [cell]
    while l[x][y] == joueur :
        x -= 1
        y += 1
        if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur :
            win += 1
        else :
            cell = checkpoint[0]
            x, y = cell
            while l[x][y] == joueur :
                x += 1
                y -= 1
                if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur:
                    win +=1
                else :
                    return win
    return win


#horizontale
def hori(cell, joueur, l):
    """loop search in horizontal for player's token
    param cell: couple, coord token
    param joueur: int, player
    param l: list, matrice
    """
    win = 1
    x, y = cell
    checkpoint = [cell]
    while l[x][y] == joueur :
        y -= 1
        if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur :
            win += 1
        else :
            cell = checkpoint[0]
            x, y = cell
            while l[x][y] == joueur :
                y += 1
                if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur:
                    win +=1
                else :
                    return win
    return win


#verticale
def vert(cell, joueur, l):
    """loop search in vertical for player's token
    param cell: couple, coord token
    param joueur: int, player
    param l: list, matrice
    """
    win = 1
    x, y = cell
    checkpoint = [cell]
    while l[x][y] == joueur :
        x -= 1
        if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur :
            win += 1
        else :
            cell = checkpoint[0]
            x, y = cell
            while l[x][y] == joueur :
                x += 1
                if 0 <= x <=5 and 0 <= y <= 6 and l[x][y] == joueur:
                    win +=1
                else :
                    return win
    return win



#test
#set = []
#for i in range(6):
#    set += [[]]
#    for j in range(7):
#        set[i] += [1]
#for ligne in set:
#    print(ligne)
#l=[
#[1, 1, 1, 1, 1, 1, 1],
#[1, 2, 1, 1, 1, 1, 1],
#[1, 1, 1, 1, 1, 1, 1],
#[1, 1, 1, 1, 1, 1, 1],
#[1, 1, 1, 1, 1, 1, 1],
#[1, 1, 1, 1, 1, 1, 1]]
