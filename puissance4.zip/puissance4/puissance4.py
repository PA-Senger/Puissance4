import graph
from fct_puissance4 import*
import time


set = create_new_game()         # nouvelle matrice de jeu
g = graph.fenetre((6, 7), 80)   # nouvelle fenetre de jeu 6*7
tour = 0                        # initialisation tour de jeu
play = True                     # statut de jeu, True = jouable
over = False                    # game over ?
while True:                     # debut de la partie
    tour += 1        # compteur de tour pour match nul et attribution joueur
    joueur = None
    if tour % 2 == 0:       # attribution du joueur
        joueur = 2
    else:
        joueur = 1
    while play == True:            # tant que le jeu est jouable
        p = g.attend_clic()                  # attend un clic de l'utilisateur
        if p[0] == "FIN" or p[0]=="<esc>":   # condition de fermeture du jeu
            g.ferme()
            exit(0)
        col = clic_col(p[1])    # fct la plus inutile du game
        playable = check_col(col, set)      # verifie si la colonne est jouable
        if playable == True:                # si jouable
            cell = drop_coord(col, set)     # coord du pion a afficher
            x, y = cell
            for i in range(x):              # dropping du pion
                set[i][y] = g.affiche_pion((i,y),joueur)
                time.sleep(0.08)
                g.supprime(set[i][y])
                set[i][y] = None
            g.affiche_pion(cell, joueur)    # affichage du pion a sa destination
            set[x][y]= joueur
            if tour == 42:                  # conditon match nul
                g.affiche_texte((240, 280),"DRAW MATCH")
                over = True                 # game over
            a = diag1((cell), joueur, set)  # check si un joueur a gagne
            b = diag2((cell), joueur, set)
            c = hori((cell), joueur, set)
            d = vert((cell), joueur, set)
            if joueur == 1:                 # condition victoire joueur 1
                if a==4 or b==4 or c==4 or d==4:
                    g.affiche_texte((240, 280),"PLAYER 1 WINS")
                    over = True             # game over
                    play = False    # empeche un nouveau tour de jeu/freeze le jeu
            if joueur == 2:                 # condition victoire joueur 2
                if a==4 or b==4 or c==4 or d==4:
                    g.affiche_texte((240, 280),"PLAYER 2 WINS")
                    over = True             # game over
                    play = False    # empeche un nouveau tour de jeu/freeze le jeu
            while over :        # si jeu terminer, attend la fermeture
                p = g.attend_clic()
                if p[0] == "FIN" or p[0]=="<esc>":
                    g.ferme()
                    exit(0)
            break   # fin de tour
